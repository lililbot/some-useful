// ============================================================
// 12 高级类型：typeof/keyof/T[K]/条件类型/infer/映射类型（Python 类型层基本无对应）
// ============================================================
export {};

// typeof（类型位置）：从值取类型
const config = { host: "localhost", port: 8080 };
type Config = typeof config;

const ROUTES = ["/home", "/about"] as const;
type Route = (typeof ROUTES)[number]; // "/home" | "/about"

// keyof：键名联合
interface User {
  name: string;
  age: number;
}
type UserKey = keyof User; // "name" | "age"

// 索引访问 T[K]
type NameType = User["name"]; // string
type UserValue = User[keyof User]; // string | number

// 条件类型：A extends B ? X : Y
type IsString<T> = T extends string ? "yes" : "no";
type A1 = IsString<string>; // "yes"
type A2 = IsString<number>; // "no"

// 条件类型 + 分发：复刻 Exclude
type MyExclude<T, U> = T extends U ? never : T;
type R1 = MyExclude<"a" | "b" | "c", "a">; // "b" | "c"

// infer：捕获类型，复刻 ReturnType / Unwrap
type MyReturnType<F> = F extends (...args: never[]) => infer R ? R : never;
type ElementOf<T> = T extends (infer E)[] ? E : never;
type Unwrap<T> = T extends Promise<infer U> ? U : T;

// 映射类型：复刻 Partial
type MyPartial<T> = { [K in keyof T]?: T[K] };
type PU = MyPartial<User>; // { name?: string; age?: number }

// 键重映射（TS 4.1+）：生成 getter 类型
type Getters<T> = {
  [K in keyof T as `get${Capitalize<string & K>}`]: () => T[K];
};
type G = Getters<User>; // { getName: () => string; getAge: () => number }

// 用运行时值演示（类型在上面已被验证可编译）
const cfg: Config = config;
const route: Route = "/home";
const patch: PU = { age: 21 };
const k: UserKey = "name";
const t1: A1 = "yes";
const t2: A2 = "no";
const r1: R1 = "b";
const nameType: NameType = "x";
const elem: ElementOf<string[]> = "e";
const unwrapped: Unwrap<Promise<number>> = 42;
const userValue: UserValue = 1;

// 运行时构造一个 Getters 形状的对象
const getters = {
  getName: () => "Bob",
  getAge: () => 20,
} satisfies G;

console.log("[12] cfg =", cfg, "| route =", route, "| patch =", patch);
console.log("[12] k =", k, "| t1 =", t1, "| t2 =", t2, "| r1 =", r1);
console.log("[12] nameType =", nameType, "| elem =", elem, "| unwrapped =", unwrapped,
  "| userValue =", userValue);
console.log("[12] getters =", getters.getName(), getters.getAge());
