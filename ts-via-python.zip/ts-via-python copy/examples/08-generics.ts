// ============================================================
// 08 泛型：TypeVar/Generic[T] → <T>；bound → extends
// ============================================================
export {};

// TypeVar("T") + def first(items: list[T]) -> T
function first<T>(items: T[]): T {
  return items[0]!;
}

// Generic[T] → class Box<T>
class Box<T> {
  constructor(private value: T) {}

  get(): T {
    return this.value;
  }

  map<R>(f: (x: T) => R): Box<R> {
    return new Box(f(this.value));
  }
}

// 约束：TypeVar("T", bound=Animal) → <T extends Animal>
interface Animal {
  name: string;
}
function feed<T extends Animal>(a: T): string {
  return `feeding ${a.name}`;
}

// 多个类型参数
class Pair<K, V> {
  constructor(public key: K, public value: V) {}
}

// keyof T 与索引访问 T[K]（Python 类型层没有）
function get<T, K extends keyof T>(obj: T, key: K): T[K] {
  return obj[key];
}

// 默认类型参数：TypeVar(default=...) → <T = ...>
interface Container<T = string> {
  value: T;
}
const c1: Container = { value: "hi" };
const c2: Container<number> = { value: 42 };

const user = { name: "Bob", age: 20 };

console.log("[08] first =", first<number>([10, 20, 30]));
console.log("[08] box =", new Box(3).map((x) => x * 2).get());
console.log("[08] feed =", feed({ name: "Rex" }));
console.log("[08] pair =", new Pair("k", 1));
console.log("[08] get(user,'age') =", get(user, "age"));
console.log("[08] container =", c1.value, c2.value);
