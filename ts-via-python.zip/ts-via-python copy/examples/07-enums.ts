// ============================================================
// 07 枚举：enum.Enum/IntEnum → enum / 字面量联合 / as const
// ============================================================
export {};

// 字符串枚举
enum Color {
  Red = "red",
  Green = "green",
  Blue = "blue",
}

// 数字枚举（有反向映射；但不做值校验，慎用）
enum Level {
  Low, // 0
  High, // 1
}

// 现代更推荐：字面量联合（无运行时产物）
type Status = "idle" | "running" | "done";

// as const 对象：既轻量又可遍历（最贴近"轻量枚举"）
const Direction = {
  Up: "up",
  Down: "down",
  Left: "left",
  Right: "right",
} as const;
type Direction = (typeof Direction)[keyof typeof Direction];

const move = (d: Direction): string => `move ${d}`;

console.log("[07] Color.Red =", Color.Red, "| Color =", Object.values(Color));
console.log("[07] Level.Low =", Level.Low, "| reverse =", Level[0]);
console.log("[07] Status =", "running" as Status);
console.log("[07] Direction =", Direction.Up, "| values =", Object.values(Direction));
console.log("[07] move =", move(Direction.Left));
