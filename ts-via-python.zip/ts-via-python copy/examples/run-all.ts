// ============================================================
// 入口：依次运行全部示例（每个文件在被 import 时执行其 console.log）
//   npm run examples
//   → tsc 编译到 dist，再用 node 运行 dist/examples/run-all.js
// ============================================================
import "./01-basics";
import "./02-functions";
import "./03-optional";
import "./04-union-intersection";
import "./05-collections";
import "./06-objects-interfaces";
import "./07-enums";
import "./08-generics";
import "./09-classes";
import "./10-narrowing";
import "./11-utility-types";
import "./12-advanced-types";
import "./13-async";

console.log("\n[run-all] 全部示例已运行完毕。");
