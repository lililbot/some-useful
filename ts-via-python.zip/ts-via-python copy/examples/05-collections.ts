// ============================================================
// 05 集合：list/dict/set/tuple → []/Record|Map/Set/tuple
// ============================================================
export {};

const nums: number[] = [3, 1, 10, 2];
const names: string[] = ["a", "b"];

// 方法映射：append→push、index→indexOf、len→length、in→includes
const pushed = [...nums];
pushed.push(99);

// 不能原地排序而影响常量语义，这里演示比较函数；数字排序必须传比较函数
const sortedAsc = [...nums].sort((a, b) => a - b);
const sortedDesc = [...nums].sort((a, b) => b - a);

// 没有列表推导式 → map / filter / reduce / some / every
const squares = nums.map((x) => x * x);
const evens = nums.filter((x) => x % 2 === 0);
const total = nums.reduce((acc, x) => acc + x, 0);
const hasBig = nums.some((x) => x > 5);
const allPos = nums.every((x) => x > 0);

// dict[str,int] → Record<string, number>
const scores: Record<string, number> = { alice: 90, bob: 85 };
const aliceScore = scores["alice"] ?? 0; // 索引访问可能为 undefined
const scoreKeys = Object.keys(scores);

// 真正的 Map：键可以是任意类型
const counts = new Map<string, number>();
for (const n of names) {
  counts.set(n, (counts.get(n) ?? 0) + 1);
}

// set[int] → Set<number>
const s = new Set<number>([1, 2, 2, 3]);
const dedupedUnique = [...new Set(nums)];

// tuple[int, str] → [number, string]
const pair: [number, string] = [1, "one"];
const [pairNum, pairStr] = pair;

console.log("[05] pushed =", pushed, "| asc =", sortedAsc, "| desc =", sortedDesc);
console.log("[05] squares =", squares, "| evens =", evens, "| total =", total);
console.log("[05] someBig =", hasBig, "| allPos =", allPos);
console.log("[05] alice =", aliceScore, "| keys =", scoreKeys);
console.log("[05] counts.b =", counts.get("b"));
console.log("[05] set =", [...s], "| dedup =", dedupedUnique);
console.log("[05] pair =", pairNum, pairStr, "| names[0] =", names[0]);
