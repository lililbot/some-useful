// ============================================================
// 02 函数：def / -> / 默认值 / *args / **kwargs / lambda / @overload / yield
// ============================================================
export {};

// def add(a: int, b: int) -> int
function add(a: number, b: number): number {
  return a + b;
}

// 默认值
function greet(name: string, greeting = "Hello"): string {
  return `${greeting}, ${name}!`;
}

// 可选参数（Python 的 str | None = None）
function greetOpt(name: string, title?: string): string {
  if (title === undefined) return `Hello, ${name}!`;
  return `Hello, ${title} ${name}!`;
}

// *args → 剩余参数
function total(...nums: number[]): number {
  return nums.reduce((a, b) => a + b, 0);
}

// **kwargs / 关键字参数 → 传一个对象并解构
interface MakeUserOptions {
  name: string;
  age?: number;
  admin?: boolean;
}
function makeUser(opts: MakeUserOptions): { name: string; age: number; admin: boolean } {
  const { name, age = 0, admin = false } = opts;
  return { name, age, admin };
}

// Callable[[int], str] → (x: number) => string
function apply(f: (x: number) => string, n: number): string {
  return f(n);
}

// 泛型回调（TypeVar 的心智）
function pipeline<T, R>(f: (x: T) => R, x: T): R {
  return f(x);
}

// @overload → 多个函数签名 + 一个实现
function parse(x: string): number;
function parse(x: Uint8Array): string;
function parse(x: string | Uint8Array): number | string {
  if (typeof x === "string") return Number(x);
  return Array.from(x).join(",");
}

// 生成器：yield → function* + Generator<T>
function* countUp(n: number): Generator<number> {
  for (let i = 0; i < n; i++) {
    yield i;
  }
}

console.log("[02] add =", add(2, 3));
console.log("[02] greet =", greet("Bob"), "|", greet("Bob", "Hi"));
console.log("[02] greetOpt =", greetOpt("Bob"), "|", greetOpt("Bob", "Dr."));
console.log("[02] total =", total(1, 2, 3, 4));
console.log("[02] makeUser =", makeUser({ name: "Carol", admin: true }));
console.log("[02] apply =", apply((x) => `#${x}`, 7));
console.log("[02] pipeline =", pipeline((x: number) => x * x, 5));
console.log("[02] parse =", parse("42"), "|", parse(new Uint8Array([104, 105])));
console.log("[02] countUp =", [...countUp(4)]);
