// ============================================================
// 09 类：__init__/继承/ABC/@property/@staticmethod → constructor/extends/abstract/get/set/static
// ============================================================
export {};

// 基础类 + 参数属性（一步完成声明 + 赋值）
class User {
  constructor(
    public name: string,
    public age: number = 0,
  ) {}

  greet(): string {
    return `Hello, ${this.name}!`;
  }
}

// 可见性：private/protected（编译期）
class Account {
  protected owner: string;
  private balance: number;

  constructor(balance: number) {
    this.balance = balance;
    this.owner = "me";
  }

  public deposit(amount: number): void {
    this.balance += amount;
  }

  public getBalance(): number {
    return this.balance;
  }
}

// 继承：class Dog(Animal) → extends；重写要 override
class Animal {
  constructor(public name: string) {}

  speak(): string {
    return "...";
  }
}

class Dog extends Animal {
  constructor(name: string, public breed: string) {
    super(name);
  }

  override speak(): string {
    return "Woof";
  }
}

// 抽象类：ABC + @abstractmethod → abstract
abstract class Shape {
  abstract area(): number;
}

class Circle extends Shape {
  constructor(public r: number) {
    super();
  }
  area(): number {
    return Math.PI * this.r ** 2;
  }
}

// @property → get / set
class Temp {
  constructor(private celsius: number) {}

  get fahrenheit(): number {
    return (this.celsius * 9) / 5 + 32;
  }

  set fahrenheit(f: number) {
    this.celsius = ((f - 32) * 5) / 9;
  }

  get c(): number {
    return this.celsius;
  }
}

// @staticmethod → static
class MathUtil {
  static square(x: number): number {
    return x * x;
  }
}

const acc = new Account(100);
acc.deposit(50);

const t = new Temp(0);
const fBefore = t.fahrenheit;
t.fahrenheit = 212; // 设完再读

console.log("[09] user =", new User("Bob", 20).greet());
console.log("[09] account balance =", acc.getBalance());
console.log("[09] dog =", new Dog("Rex", "Husky").speak(), "| instanceof Animal:",
  new Dog("Rex", "Husky") instanceof Animal);
console.log("[09] circle area =", new Circle(1).area().toFixed(3));
console.log("[09] temp 0C =", fBefore, "F | after set 212F ->", t.c.toFixed(1), "C");
console.log("[09] static =", MathUtil.square(6));
